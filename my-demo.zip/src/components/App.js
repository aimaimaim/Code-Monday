import React from 'react';


import MyTable from './MyTable';


const App = () =>{
    return (
        <div >
           {/* <Button variant="contained">Default</Button> */}
           <MyTable/>
           
        </div>
    )
}


export default App;
