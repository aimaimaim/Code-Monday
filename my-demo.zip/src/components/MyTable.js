/*import React from 'react';

import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Button from '@material-ui/core/Button';











class MyTable extends React.Component{

    constructor(props) {
      super(props);
      this.state = {
        covid: {
          Countries:[],
          Global:{},
          
        }
        
      };
    }

    componentDidMount(){
        fetch('https://api.covid19api.com/summary')
        .then(response => response.json())
        .then(data => {
          console.log(data);
          this.setState({ covid: data })
        });
      
    }


    render(){
        
        const {covid} = this.state;

        console.log("d"+covid.Countries.TotalDeaths);
        return (
          <body>
          <div >
            <p align = "center" >
          <b> This is Covid-19 Report as of {covid.Date}
            <TableContainer component={Paper}>
              <Table align="center"  aria-label="simple table" style={{'width':'1000px', "borderWidth":"1px", 'borderColor':"#aaaaaa", 'borderStyle':'solid'}} >
                <TableHead>
                  <TableRow >
                    <TableCell ><b2>Country</b2></TableCell>
                    <TableCell align="right"><b2>Total confirmed cases</b2></TableCell>
                    <TableCell align="right"><b2>Total death cases</b2></TableCell>
                    <TableCell align="right"><b2>Total recovered cases</b2></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>

                }
                  {covid.Countries.map((row) => (  
                    <TableRow key={row.ID}>
                      <TableCell padding="none" align="left" >{row.Country}</TableCell>
                      <TableCell padding="none" align="right">{row.TotalConfirmed === 0 ? 'Unreported': row.TotalConfirmed}</TableCell>
                      <TableCell padding="none" align="right">{row.TotalDeaths === 0 ? 'Unreported' : row.TotalDeaths}</TableCell>
                      <TableCell padding="none" align="right">{row.TotalRecovered}</TableCell>

                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            
            </b></p>
            
            <Button variant="contained" color="primary">
              GLHF
            </Button>
            <Button variant="contained" color="secondary">
              Sign out
            </Button>
            </div></body>
          
        );
    }
}

export default MyTable;

*/
import React from 'react';
import MUIDataTable from "mui-datatables";

class MyTable extends React.Component{

  
  constructor(props) {
    super(props);
    this.state = {
      covid: {
        Countries:[],
        Global:{},
        
      }
      
    };
  }

  componentDidMount(){
      fetch('https://api.covid19api.com/summary')
      .then(response => response.json())
      .then(data => {
        console.log(data);
        this.setState({ covid: data })
      });
    
  }

render(){

  const {covid} = this.state;
  //ติดตรงนี้ log covid.Countryออกมาได้ undefined
  console.log("d"+typeof covid.Countries[0]);
  const columns = ["Country Name","Total confirmed cases", "Total death cases", "Total recovered cases"];
// covid.Countries.map((row)=>(row.Country))

const data = ['a','a'];

const options = {
  filterType: 'checkbox',
};
  
  return(

    <MUIDataTable
  title={"This is Covid-19 Report as of "+covid.Date}
  data={data}
  columns={columns}
  options={options}
/>


);}
  

  }
export default MyTable;

